/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

/**
 *
 * @author FA20-BSE-165
 */
public class Student implements Observer {
    private String name;
    private Subject matchSubject;

    public Student(String name, Subject matchSubject) {
        this.name = name;
        this.matchSubject = matchSubject;
        matchSubject.registerObserver(this);
    }

    public String getName() {
        return name;
    }

    public Subject getMatchSubject() {
        return matchSubject;
    }

    @Override
    public void onMatchUpdate(Match match) {
        System.out.println(name + " received match update: " + match.getName() + " (" + match.getScoreTeamA() + " - " + match.getScoreTeamB() + ")");
    }
}

