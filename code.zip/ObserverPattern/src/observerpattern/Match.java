/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

/**
 *
 * @author FA20-BSE-165
 */
public class Match {
    private String name;
    private int scoreTeamA;
    private int scoreTeamB;

    public Match(String name, int scoreTeamA, int scoreTeamB) {
        this.name = name;
        this.scoreTeamA = scoreTeamA;
        this.scoreTeamB = scoreTeamB;
    }

    public String getName() {
        return name;
    }

    public int getScoreTeamA() {
        return scoreTeamA;
    }

    public int getScoreTeamB() {
        return scoreTeamB;
    }
}

